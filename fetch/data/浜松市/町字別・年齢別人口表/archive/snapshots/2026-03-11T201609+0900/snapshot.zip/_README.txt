Dataset: 町字別・年齢別人口表
Publisher: 浜松市
Snapshot: 2026-03-11T201609+0900 (JST)
BaselineFixedCounts(as_of=2025-12-15 / scope=old+before / expected_total=329)

This folder is an immutable archive snapshot of the official distributed files.
DO NOT edit/overwrite files in this snapshot.
Use a separate 'raw' (working copy) layer for any processing.

Integrity can be verified by sha256 hashes recorded in _manifest_download.csv.
